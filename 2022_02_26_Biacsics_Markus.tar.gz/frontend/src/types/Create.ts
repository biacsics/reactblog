export interface CreateResultBody {
  id: string;
}
