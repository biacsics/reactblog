export interface ViewData {
  id: string;
  title: string;
  content: string;
  publishedAt: string;
  modifiedAt: string;
}
